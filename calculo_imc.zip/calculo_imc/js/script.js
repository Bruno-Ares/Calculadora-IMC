const inputNome = document.querySelector("#inputNome")
const inputSexoM = document.querySelector("#inputSexM")
const inputSexoF = document.querySelector("#inputSexF")
const inputPeso = document.querySelector("#inputPeso")
const inputAltura = document.querySelector("#inputAltura")

const btnEnviar = document.querySelector("#btnEnviar")
const btnApagar = document.querySelector("#btnApagar")

btnEnviar.addEventListener("click", ()=>{
    let imc
    let medida1, medida2, medida3, medida4, medNeces

   let peso = parseFloat(inputPeso.value)
   let altura = parseFloat(inputAltura.value)
    let pesoNormal = (altura**2)*25.0


    if (inputSexoF.checked)
    {
        medida1 = 19.1
        medida2 = 25.8
        medida3 = 27.3
        medida4 = 32.3
    }
    else if (inputSexoM.checked)
    {
        medida1 = 20.7
        medida2 = 26.4
        medida3 = 27.8
        medida4 = 31.3
    } 

    if ((inputNome.value) && (inputAltura.value) && (parseFloat(inputAltura.value) != 0) && (inputPeso.value) && ((inputSexoM.checked) || (inputSexoF.checked)))
    {
        document.getElementById("divNome").innerHTML = "Olá, " + inputNome.value + "."

        imc = parseFloat(peso / (altura**2))

        document.getElementById("divIMC").innerHTML = "Seu IMC é: " + imc.toFixed(2)

        if (imc < medida1)
        {

            document.getElementById("divResultado").innerHTML = "Sua classificação é: Abaixo do peso."
            medNeces = parseFloat(pesoNormal - peso)
            document.getElementById("divPeso").innerHTML = "Você deve ganhar no mínimo" + medNeces.toFixed(2) + " kg"
            divResposta.setAttribute("class", "vermelho")
            divResultado.setAttribute("class", "grave")

        } 
        else if ((imc >= medida1) && (imc <= medida2))
        {

            medNeces = parseFloat(peso - pesoNormal)
            document.getElementById("divResultado").innerHTML = "Sua classificação é: Peso normal."
            document.getElementById("divPeso").innerHTML = "Continue assim!"
            divResposta.setAttribute("class", "verde")
            divResultado.setAttribute("class", "normal")

        }
        else if ((imc > medida2 ) && (imc <= medida3))
        {

            document.getElementById("divResultado").innerHTML = "Sua classificação é: Marginalmente acima do peso."
            medNeces = parseFloat(peso - pesoNormal)
            document.getElementById("divPeso").innerHTML = "Você deve perder no mínimo " + medNeces.toFixed(2) + " kg."

            divResposta.setAttribute("class", "amarelo")
            divResultado.setAttribute("class", "marginal")
 
        }

        else if ((imc > medida3) && (imc <= medida4))
        {
            document.getElementById("divResultado").innerHTML = "Acima do peso ideal."
            medNeces = parseFloat(peso - pesoNormal)
            document.getElementById("divPeso").innerHTML = "Você deve perder no mínimo " + medNeces.toFixed(2) + " kg."
            divResposta.setAttribute("class", "laranja")
            divResultado.setAttribute("class", "sobrepeso")
        } 
        else
        {
            document.getElementById("divResultado").innerHTML = "Sua classificação é: Obeso."
            medNeces = parseFloat(peso - pesoNormal)
            document.getElementById("divPeso").innerHTML = "Você deve perder no mínimo" + medNeces.toFixed(2) + " kg."
            divResposta.setAttribute("class", "vermelho")
            divResultado.setAttribute("class", "grave")
        }

    } 
    else
    {
        alert("Preencha todos os campos.")
    }

})

btnApagar.addEventListener("click", ()=>{
    inputNome.value = ""
    inputPeso.value = ""
    inputSexo.value = ""
    inputAltura.value = ""

})
